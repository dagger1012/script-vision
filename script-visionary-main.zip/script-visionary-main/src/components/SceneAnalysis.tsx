import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Film, Users, Clock, Palette, ChevronRight } from "lucide-react";

interface Scene {
  id: number;
  setting: string;
  characters: string[];
  dialogue: string[];
  action: string[];
  summary: string;
  tone: string;
  duration: string;
}

interface SceneAnalysisProps {
  scenes: Scene[];
  onSceneSelect: (scene: Scene) => void;
}

export const SceneAnalysis = ({ scenes, onSceneSelect }: SceneAnalysisProps) => {
  const [selectedScene, setSelectedScene] = useState<Scene | null>(null);

  const getToneColor = (tone: string) => {
    switch (tone) {
      case 'dramatic': return 'bg-red-500/10 text-red-400 border-red-500/20';
      case 'comedic': return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20';
      case 'suspenseful': return 'bg-purple-500/10 text-purple-400 border-purple-500/20';
      case 'romantic': return 'bg-pink-500/10 text-pink-400 border-pink-500/20';
      case 'action': return 'bg-orange-500/10 text-orange-400 border-orange-500/20';
      default: return 'bg-primary/10 text-primary border-primary/20';
    }
  };

  const handleSceneClick = (scene: Scene) => {
    setSelectedScene(scene);
    onSceneSelect(scene);
  };

  return (
    <section className="py-20 px-6 bg-secondary/20">
      <div className="container mx-auto max-w-7xl">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">Scene Analysis</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Review the AI-analyzed scenes from your script. Select a scene to generate storyboards.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Scene List */}
          <div className="space-y-4">
            <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Film className="w-5 h-5 text-primary" />
              Scenes ({scenes.length})
            </h3>
            
            <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
              {scenes.map((scene) => (
                <Card 
                  key={scene.id}
                  className={`cursor-pointer transition-all duration-300 hover:shadow-lg ${
                    selectedScene?.id === scene.id 
                      ? 'border-primary shadow-glow' 
                      : 'border-border hover:border-primary/30'
                  }`}
                  onClick={() => handleSceneClick(scene)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="font-semibold text-primary">Scene {scene.id}</span>
                          <Badge className={getToneColor(scene.tone)}>
                            {scene.tone}
                          </Badge>
                        </div>
                        <p className="text-sm font-medium mb-2">{scene.setting}</p>
                        <p className="text-xs text-muted-foreground mb-2 line-clamp-2">
                          {scene.summary}
                        </p>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Users className="w-3 h-3" />
                            {scene.characters.length} characters
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {scene.duration}
                          </span>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-muted-foreground ml-2 flex-shrink-0" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
          
          {/* Scene Details */}
          <div>
            <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Palette className="w-5 h-5 text-accent" />
              Scene Details
            </h3>
            
            {selectedScene ? (
              <Card className="border-primary/20">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Scene {selectedScene.id}</span>
                    <Badge className={getToneColor(selectedScene.tone)}>
                      {selectedScene.tone}
                    </Badge>
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">{selectedScene.setting}</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">Characters</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedScene.characters.map((character, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {character}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  {selectedScene.action.length > 0 && (
                    <div>
                      <h4 className="font-medium mb-2">Key Action</h4>
                      <div className="text-sm text-muted-foreground space-y-1 max-h-24 overflow-y-auto">
                        {selectedScene.action.slice(0, 3).map((action, index) => (
                          <p key={index}>• {action}</p>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  <div className="pt-4">
                    <Button 
                      variant="hero" 
                      className="w-full"
                      onClick={() => {
                        // This will be handled by parent component
                        document.getElementById('storyboard-section')?.scrollIntoView({ 
                          behavior: 'smooth' 
                        });
                      }}
                    >
                      <Palette className="w-4 h-4 mr-2" />
                      Generate Storyboards
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="border-dashed border-primary/20">
                <CardContent className="p-8 text-center text-muted-foreground">
                  <Film className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Select a scene from the left to view details and generate storyboards</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};