import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Palette, Wand2, Download, RefreshCw, Film, Sparkles } from "lucide-react";
import { toast } from "sonner";

interface Scene {
  id: number;
  setting: string;
  characters: string[];
  summary: string;
  tone: string;
}

interface StoryboardGenerationProps {
  selectedScene: Scene | null;
}

interface StoryboardPanel {
  id: number;
  imageUrl: string;
  description: string;
  shotType: string;
}

export const StoryboardGeneration = ({ selectedScene }: StoryboardGenerationProps) => {
  const [stylePrompt, setStylePrompt] = useState("cinematic, professional storyboard style, black and white sketches");
  const [isGenerating, setIsGenerating] = useState(false);
  const [storyboards, setStoryboards] = useState<StoryboardPanel[]>([]);
  const [panelCount, setPanelCount] = useState(4);

  const stylePresets = [
    "cinematic, professional storyboard style, black and white sketches",
    "film noir, high contrast, dramatic lighting",
    "animated style, colorful, cartoon-like",
    "realistic photography, cinematic composition",
    "comic book style, bold lines, dynamic angles",
    "minimalist, clean lines, simple composition"
  ];

  const generateStoryboards = async () => {
    if (!selectedScene) {
      toast.error("Please select a scene first");
      return;
    }
    
    setIsGenerating(true);
    
    try {
      // Simulate AI storyboard generation
      const mockPanels: StoryboardPanel[] = Array.from({ length: panelCount }, (_, i) => ({
        id: i + 1,
        imageUrl: `https://images.unsplash.com/photo-${1550000000000 + i}?w=400&h=300&fit=crop`,
        description: `Panel ${i + 1}: ${selectedScene.summary} - ${['Wide shot establishing the scene', 'Medium shot of main character', 'Close-up reaction shot', 'Over-shoulder dialogue', 'Action sequence', 'Final reveal shot'][i] || 'Cinematic moment'}`,
        shotType: ['Wide Shot', 'Medium Shot', 'Close-Up', 'Over-Shoulder', 'Action Shot', 'Detail Shot'][i] || 'Medium Shot'
      }));
      
      // Simulate generation time
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      setStoryboards(mockPanels);
      toast.success(`Generated ${panelCount} storyboard panels!`);
    } catch (error) {
      toast.error("Failed to generate storyboards. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const regeneratePanel = async (panelId: number) => {
    setStoryboards(prev => prev.map(panel => 
      panel.id === panelId 
        ? { ...panel, imageUrl: `https://images.unsplash.com/photo-${Date.now()}?w=400&h=300&fit=crop` }
        : panel
    ));
    toast.success("Panel regenerated!");
  };

  return (
    <section id="storyboard-section" className="py-20 px-6">
      <div className="container mx-auto max-w-7xl">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4 flex items-center justify-center gap-3">
            <Wand2 className="w-8 h-8 text-primary" />
            Storyboard Generation
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Generate visual storyboards for your selected scene with AI-powered artistic styles.
          </p>
        </div>

        {selectedScene ? (
          <div className="space-y-8">
            {/* Scene Info & Controls */}
            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Film className="w-5 h-5 text-primary" />
                  Scene {selectedScene.id}: {selectedScene.setting}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid lg:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="style-prompt" className="text-sm font-medium mb-2 block">
                        Style Prompt
                      </Label>
                      <Textarea
                        id="style-prompt"
                        value={stylePrompt}
                        onChange={(e) => setStylePrompt(e.target.value)}
                        placeholder="Describe the visual style you want..."
                        className="min-h-20"
                      />
                    </div>
                    
                    <div className="flex flex-wrap gap-2">
                      {stylePresets.map((preset, index) => (
                        <Badge
                          key={index}
                          variant="secondary"
                          className="cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors text-xs"
                          onClick={() => setStylePrompt(preset)}
                        >
                          {preset.split(',')[0]}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="panel-count" className="text-sm font-medium mb-2 block">
                        Number of Panels
                      </Label>
                      <Input
                        id="panel-count"
                        type="number"
                        min="3"
                        max="8"
                        value={panelCount}
                        onChange={(e) => setPanelCount(Math.min(8, Math.max(3, parseInt(e.target.value) || 4)))}
                      />
                    </div>
                    
                    <Button
                      variant="hero"
                      className="w-full"
                      onClick={generateStoryboards}
                      disabled={isGenerating}
                    >
                      {isGenerating ? (
                        <>
                          <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                          Generating Storyboards...
                        </>
                      ) : (
                        <>
                          <Palette className="w-4 h-4 mr-2" />
                          Generate Storyboards
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Generated Storyboards */}
            {storyboards.length > 0 && (
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <Film className="w-5 h-5 text-accent" />
                      Generated Storyboards
                    </CardTitle>
                    <Button variant="outline" size="sm">
                      <Download className="w-4 h-4 mr-2" />
                      Download All
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {storyboards.map((panel) => (
                      <Card key={panel.id} className="group hover:shadow-lg transition-all duration-300">
                        <div className="aspect-video relative overflow-hidden rounded-t-lg">
                          <img
                            src={panel.imageUrl}
                            alt={panel.description}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                            <Button
                              variant="secondary"
                              size="sm"
                              onClick={() => regeneratePanel(panel.id)}
                            >
                              <RefreshCw className="w-4 h-4 mr-1" />
                              Regenerate
                            </Button>
                          </div>
                          <Badge className="absolute top-2 left-2 bg-black/50 text-white">
                            Panel {panel.id}
                          </Badge>
                        </div>
                        <CardContent className="p-4">
                          <div className="space-y-2">
                            <Badge variant="outline" className="text-xs">
                              {panel.shotType}
                            </Badge>
                            <p className="text-sm text-muted-foreground line-clamp-2">
                              {panel.description}
                            </p>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        ) : (
          <Card className="border-dashed border-primary/20">
            <CardContent className="p-12 text-center text-muted-foreground">
              <Palette className="w-16 h-16 mx-auto mb-6 opacity-50" />
              <h3 className="text-xl font-medium mb-2">No Scene Selected</h3>
              <p className="max-w-md mx-auto">
                Please upload and analyze a script, then select a scene to generate storyboards.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </section>
  );
};