import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Upload, FileText, Check, AlertCircle } from "lucide-react";
import { toast } from "sonner";

interface ScriptUploadProps {
  onScriptParsed: (scriptData: any) => void;
}

export const ScriptUpload = ({ onScriptParsed }: ScriptUploadProps) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);

  const parseScript = async (content: string) => {
    // Simulate AI parsing with structured output
    const lines = content.split('\n').filter(line => line.trim());
    const scenes = [];
    let currentScene: any = null;
    
    for (const line of lines) {
      const trimmedLine = line.trim();
      
      // Scene headers (INT./EXT.)
      if (trimmedLine.match(/^(INT\.|EXT\.)/i)) {
        if (currentScene) scenes.push(currentScene);
        currentScene = {
          id: scenes.length + 1,
          setting: trimmedLine,
          characters: new Set(),
          dialogue: [],
          action: [],
          summary: "",
          tone: "neutral"
        };
      }
      // Character names (ALL CAPS at start of line)
      else if (trimmedLine.match(/^[A-Z][A-Z\s]+$/) && currentScene) {
        currentScene.characters.add(trimmedLine);
      }
      // Dialogue and action
      else if (trimmedLine && currentScene) {
        if (trimmedLine.match(/^[A-Z]/)) {
          currentScene.action.push(trimmedLine);
        } else {
          currentScene.dialogue.push(trimmedLine);
        }
      }
    }
    
    if (currentScene) scenes.push(currentScene);
    
    // Convert Sets to Arrays and add AI-generated metadata
    return scenes.map((scene: any) => ({
      ...scene,
      characters: Array.from(scene.characters),
      summary: `Scene ${scene.id}: ${scene.setting.toLowerCase().replace(/^(int\.|ext\.)/, '').trim()}`,
      tone: ["dramatic", "comedic", "suspenseful", "romantic", "action"][Math.floor(Math.random() * 5)],
      duration: Math.floor(Math.random() * 5 + 1) + " minutes"
    }));
  };

  const handleFileSelect = useCallback(async (file: File) => {
    if (!file.name.endsWith('.txt')) {
      toast.error("Please upload a .txt file");
      return;
    }
    
    setUploadedFile(file);
    setIsProcessing(true);
    
    try {
      const content = await file.text();
      const parsedScript = await parseScript(content);
      
      setTimeout(() => {
        onScriptParsed(parsedScript);
        setIsProcessing(false);
        toast.success(`Successfully parsed ${parsedScript.length} scenes from your script!`);
      }, 2000); // Simulate processing time
      
    } catch (error) {
      setIsProcessing(false);
      toast.error("Error parsing script. Please check the file format.");
    }
  }, [onScriptParsed]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  }, [handleFileSelect]);

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  return (
    <section className="py-20 px-6">
      <div className="container mx-auto max-w-4xl">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">Upload Your Screenplay</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Upload your script file (.txt format) and let our AI analyze the scenes, characters, and structure.
          </p>
        </div>
        
        <Card className="relative overflow-hidden border-2 border-dashed border-primary/20 hover:border-primary/40 transition-all duration-300">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2">
              <FileText className="w-6 h-6 text-primary" />
              Script Analysis
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div
              className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-all duration-300 ${
                isDragging 
                  ? 'border-primary bg-primary/5 scale-105' 
                  : 'border-border hover:border-primary/50'
              } ${isProcessing ? 'animate-pulse' : ''}`}
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
            >
              {isProcessing ? (
                <div className="space-y-4">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto animate-spin">
                    <Upload className="w-8 h-8 text-primary" />
                  </div>
                  <p className="text-lg font-medium">Analyzing Your Script...</p>
                  <p className="text-muted-foreground">Parsing scenes and extracting characters</p>
                </div>
              ) : uploadedFile ? (
                <div className="space-y-4">
                  <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center mx-auto">
                    <Check className="w-8 h-8 text-green-500" />
                  </div>
                  <p className="text-lg font-medium">Script Uploaded Successfully!</p>
                  <p className="text-muted-foreground">{uploadedFile.name}</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                    <Upload className="w-8 h-8 text-primary" />
                  </div>
                  <div>
                    <p className="text-lg font-medium mb-2">Drop your script file here</p>
                    <p className="text-muted-foreground mb-4">or click to browse files</p>
                    <input
                      type="file"
                      accept=".txt"
                      onChange={handleFileInput}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                    <Button variant="cinema" className="pointer-events-none">
                      Choose File
                    </Button>
                  </div>
                  <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                    <AlertCircle className="w-4 h-4" />
                    Supports .txt files up to 10MB
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};