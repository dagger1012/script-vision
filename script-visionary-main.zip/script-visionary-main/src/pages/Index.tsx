import { useState } from "react";
import { HeroSection } from "@/components/HeroSection";
import { ScriptUpload } from "@/components/ScriptUpload";
import { SceneAnalysis } from "@/components/SceneAnalysis";
import { StoryboardGeneration } from "@/components/StoryboardGeneration";

interface Scene {
  id: number;
  setting: string;
  characters: string[];
  dialogue: string[];
  action: string[];
  summary: string;
  tone: string;
  duration: string;
}

const Index = () => {
  const [parsedScenes, setParsedScenes] = useState<Scene[]>([]);
  const [selectedScene, setSelectedScene] = useState<Scene | null>(null);

  const handleScriptParsed = (scenes: Scene[]) => {
    setParsedScenes(scenes);
  };

  const handleSceneSelect = (scene: Scene) => {
    setSelectedScene(scene);
  };

  return (
    <div className="min-h-screen bg-background">
      {parsedScenes.length === 0 ? (
        <>
          <HeroSection />
          <ScriptUpload onScriptParsed={handleScriptParsed} />
        </>
      ) : (
        <>
          <SceneAnalysis 
            scenes={parsedScenes} 
            onSceneSelect={handleSceneSelect} 
          />
          <StoryboardGeneration selectedScene={selectedScene} />
        </>
      )}
    </div>
  );
};

export default Index;
